#!/usr/bin/python

import sys, os

def ns2ms(base, filename):
    basef = open(base, "r")
    file  = open(filename, "r")
    i    = 0

    for ln in file.readlines():
        baseln = basef.readline()
        basev  = float(baseln.split()[1])
        value  = float(ln.split()[1])
        print "%d\t%f" % (i, value/basev)
        i = i + 1

# main
ns2ms(sys.argv[1], sys.argv[2])
