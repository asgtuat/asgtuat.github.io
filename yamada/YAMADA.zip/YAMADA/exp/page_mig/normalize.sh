#!/bin/bash

for i in `seq 1 5`
do
    ./normalize.py copy_ms.dat batch_"$i"_ms.dat > batch_"$i"_normalized.dat
done
