#!/bin/bash

./ns2ms.py copy.dat > copy_ms.dat

for i in `seq 1 5`
do
    ./ns2ms.py batch_"$i".dat > batch_"$i"_ms.dat
done

