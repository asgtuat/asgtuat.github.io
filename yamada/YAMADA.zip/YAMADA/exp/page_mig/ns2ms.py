#!/usr/bin/python

import sys, os

def ns2ms(filename):
    file = open(filename, "r")
    i    = 0
    for ln in file.readlines():
        value = float(ln.split()[1])
        print "%d\t%f" % (i, value/10000.0)
        i = i + 1

# main
ns2ms(sys.argv[1])

