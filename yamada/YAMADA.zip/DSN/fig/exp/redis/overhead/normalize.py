#!/usr/bin/python
import sys, os

def normalize(filename):
    f = open(filename, "r")
    i = 0
    for line in f.readlines():
        ln  = line.split()
        ovh = float(ln[1]) / float(ln[2])
        print "%d 1 %f" % (i, ovh)
        i  += 1
         


# main
normalize(sys.argv[1])
