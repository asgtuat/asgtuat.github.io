#!/usr/bin/python

import os, sys, csv

def log2dat(offset, filename, entry):
    f = open(filename, 'r')
    
    reader  = csv.reader(f)
    counter = 0
    for row in reader:
        if counter == 0:
            counter = int(offset)
            counter += 1
            continue
        print "%d\t%s" % (counter, row[int(entry)])
        counter += 1

#main
log2dat(sys.argv[1], sys.argv[2], sys.argv[3])


